import { useState } from "react";
import {
  Button,
  Card,
  Container,
  List,
  makeStyles,
  TextField,
} from "@material-ui/core";
import Item from "./Item";
import CustomAppBar from "./CustomAppBar";

const useStyles = makeStyles({
  root: {
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    background: "#F5FAFA",
  },
  container: {
    display: "flex",
    flex: 1,
    flexDirection: "column",
  },
  textInput: {
    marginRight: 15,
    marginBottom: 15,
  },
  numberInput: {
    width: 80,
    marginRight: 15,
    marginBottom: 15,
  },
  form: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
  },
  card: {
    padding: 15,
    margin: 15,
  },
});

function App() {
  const classes = useStyles();

  const [shoppingList, setShoppingList] = useState([
    { title: "bananas", quantity: 2 },
    { title: "cherries", quantity: 5 },
  ]);

  const [currentItem, setCurrentItem] = useState("");
  const [currentNumber, setCurrentNumber] = useState(0);

  const addItem = (e) => {

    var a ={}
    a['title']=document.getElementById('Fruit');
    a['quantity']=document.getElementById('Quantité');

    shoppingList.push(a);
    setCurrentNumber(currentNumber + 1);
    onTextChanged();

    // code here
    // don't forget to clear the input values after adding an item to the list
  };

  const removeItem = (index) => {
item=event.target.value;
    var index = shoppingList.indexOf(item);

    //// On peut aussi faire :
    index=event.target.index;

    if (index > -1) {
      shoppingList.splice(index, 1);
      return shoppingList
  }
setCurrentNumber(currentNumber - 1);
    onTextChanged();

  };

  const onTextChanged = (e) => {

    List.innerHTML = "
      {shoppingList.map((item, key) => {
        return (
          <Item item={item} key={key} index={key} removeCallback={removeItem} />
        );
      })}
   ";
  };

  const onNumberChanged = (e) => {
    // code here
    // oups, nothing happens when you type in the input, change this part to fix that
  };

  return (
    <div className={classes.root}>
      <CustomAppBar />
      <div className={classes.container}>
        <Container maxWidth="sm">
          <Card className={classes.card}>
            <form onSubmit={addItem}>
              <div className={classes.form}>
                <div>
                  <TextField
                    className={classes.textInput}
                    label="Item"
                    id='fruit'
                    value={currentItem}
                    onChange={onTextChanged}
                  />
                </div>
                <div>
                  <TextField
                    type="number"
                    className={classes.numberInput}
                    label="Quantity"
                    id='Quantity'
                    value={currentNumber}
                    onChange={onNumberChanged}
                  />
                </div>
                <div>
                  <Button type="submit" variant="contained" color="primary" onClick=add()>
                    Add
                  </Button>
                </div>
              </div>
            </form>
          </Card>
          <Card className={classes.card}>
            <List>
              {shoppingList.map((item, key) => {
                return (
                  <Item item={item} key={key} index={key} removeCallback={removeItem(event} />
                );
              })}
            </List>
          </Card>
        </Container>
      </div>
    </div>
  );
}

export default App;
